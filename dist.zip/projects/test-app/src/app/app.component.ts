import { Component, OnDestroy, OnInit } from '@angular/core';
import { SlideConfig } from 'dist/ngx-edge-slider/lib/ngx-edge-slider.interface';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit, OnDestroy {
  title = 'test-app';

  slides = [
    {
     id: 0, 
     image: "assets/slide2_desktop_1950x.webp",
    }, 

    {
      id: 1, 
      image: "assets/slide2_desktop_1950x.webp"
    }
  ];

  isAnimating = false;
  isMobile: boolean;

  // Config is inside of ngx-edge-slider.interface.ts, check scss file also for string options.
  sliderConfig: any = {
    slideWidth: 100, 
    slidesPerView: 1, 
    slideChangeDelay: 50,
    draggable: true,
    delay: 5000, 
    navEnabled:true,
    navHoverable:true,
    navPosition: 'centered',
    paginationEnabled: true,
    paginationPosition: 'thumbs-bottom', 
    breakpoints: {
      desktop: { autoplay: true }
    }
  };


  ngOnInit(): void {
    this.sliderConfig.slides = this.slides;
  }

  ngOnDestroy(): void {
   // slider destroys itself automatic.
  }

  onSlideChange($event: any): void {
    console.log($event)
  }
}
