/*
 * Public API Surface of ngx-edge-slider
 */

export * from './lib/ngx-edge-slider.service';
export * from './lib/ngx-edge-slider.component';
export * from './lib/ngx-edge-slider.module';
