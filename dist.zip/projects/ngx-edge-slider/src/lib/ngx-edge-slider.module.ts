import { NgModule } from '@angular/core';
import { NgxEdgeSliderComponent } from './ngx-edge-slider.component';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [
    NgxEdgeSliderComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    NgxEdgeSliderComponent
  ]
})
export class NgxEdgeSliderModule { }
